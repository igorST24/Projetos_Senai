/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.crud;

/**
 *
 * @author isantos
 */
public class Crud {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
