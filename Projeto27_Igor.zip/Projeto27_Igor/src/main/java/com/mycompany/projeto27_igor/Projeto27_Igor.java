/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto27_igor;

import javax.swing.*;
import java.awt.*;
/**
 *
 * @author isantos
 */
public class Projeto27_Igor extends JFrame {
    private JTextField nomeFuncionario, sobrenomeFuncionario, emailFuncionario, cargoFuncionario, senhaUsuario;
    private JButton cadastrarUsuario, cancelar;
    
    public Projeto27_Igor () {
        // Configurações básicas da janela
        setTitle("Cadastro de Funcionários");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null);
        
        // Criação dos campos de texto
        nomeFuncionario = new JTextField(10);
        sobrenomeFuncionario = new JTextField(10);
        emailFuncionario = new JTextField(10);
        cargoFuncionario = new JTextField(10);
        senhaUsuario = new JTextField(10);
        
        // Criação dos botões
       cadastrarUsuario = new JButton("Cadastrar");
       cancelar = new JButton("Cancelar");
       
       // Layout
       setLayout(new GridLayout(6, 3));
       
       // Adicionando os componentes à janela
       add(new JLabel("Nome: "));
       add(nomeFuncionario);
       add(new JLabel("Sobrenome: "));
       add(sobrenomeFuncionario);
       add(new JLabel("E-mail: "));
       add(emailFuncionario);
       add(new JLabel("Cargo: "));
       add(cargoFuncionario);
       add(new JLabel("Senha: "));
       add(senhaUsuario);
       add(cadastrarUsuario);
       add(cancelar);
       
       setVisible(true);
    }
     
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
               new Projeto27_Igor();
            }
        });
    }
}
